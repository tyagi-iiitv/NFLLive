
The file which matters most in here is skiena-example.tex, which is the template for your background report.

Another latex example with more details on formatting is typeinst.tex.   Also llncsdoc.pdf


